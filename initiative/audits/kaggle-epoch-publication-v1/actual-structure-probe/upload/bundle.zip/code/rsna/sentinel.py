"""Synthetic upload-structure sentinel; no training or inference."""
STRUCTURE_SENTINEL = "rsna-private-zip-structure-v1"
